/*
 * Robot.h
 *
 *  Created on: Jan 7, 2015
 *      Author: paulugolini
 */
#include "WPILib.h"

#define RATEGYRO1 0
#define POTE 1

#ifndef SRC_ROBOT_H_
#define SRC_ROBOT_H_

enum preset {WIDE,LONG};

#endif /* SRC_ROBOT_H_ */
