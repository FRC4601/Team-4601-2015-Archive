/*
 * Joysticks.h
 *
 *  Created on: Mar 10, 2015
 *      Author: paulugolini
 */

#include "WPILib.h"

#ifndef SRC_JOYSTICKS_H_
#define SRC_JOYSTICKS_H_

int lZA = 0;


#endif /* SRC_JOYSTICKS_H_ */
